export interface Especialidad {
    id:number,
    nombre:string,
}