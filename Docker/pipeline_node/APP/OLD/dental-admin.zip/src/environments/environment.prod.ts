export const environment = {
  production: true,
  ENDPOINT_API : 'http://localhost:3000'
};
